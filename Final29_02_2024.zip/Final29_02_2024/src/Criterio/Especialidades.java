package Criterio;

import Carpinteria.Elemento;

public interface Especialidades {
    boolean cumple(Elemento e);
}
