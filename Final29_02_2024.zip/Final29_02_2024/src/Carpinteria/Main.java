package Carpinteria;

import Calculador.AdicionalFijo;
import Calculador.AplicoAdicional;
import Calculador.PorcentajeAdicional;
import Criterio.CriterioMayorPeso;

public class Main {
    public static void main(String[] args) {
       
    }
}
