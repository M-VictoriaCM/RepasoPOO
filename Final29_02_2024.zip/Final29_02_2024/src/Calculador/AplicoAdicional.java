package Calculador;

import Carpinteria.Elemento;

public interface AplicoAdicional {
    double calcular(Elemento e);
}
